from django.apps import AppConfig


class AmsAppConfig(AppConfig):
    name = 'ams_app'
