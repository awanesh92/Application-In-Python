from __future__ import unicode_literals

import ams_app.models
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Assignment',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('title', models.CharField(max_length=255)),
                ('passcode', models.CharField(default=ams_app.models.unique_passcode, max_length=100)),
                ('upload', models.FileField(null=True, upload_to='assignments/')),
                ('due_date', models.DateField()),
                ('created_at', models.DateField(auto_now_add=True)),
                ('last_updated', models.DateField(auto_now=True)),
                ('course_code', models.CharField(max_length=8)),
                ('course_title', models.CharField(max_length=255)),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='assignments', to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Profile',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('role', models.CharField(choices=[('Instruct', 'Instruct'), ('Student', 'Student')], default='Instruct', max_length=100)),
                ('matric_number', models.CharField(blank=True, max_length=12, null=True, unique=True)),
                ('user', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Submission',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('matric_number', models.CharField(max_length=12)),
                ('upload', models.FileField(upload_to='submissions/')),
                ('submitted_at', models.DateField(auto_now=True)),
                ('last_updated', models.DateField(auto_now=True)),
                ('grade', models.CharField(max_length=100)),
                ('assignment', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='submissions', to='ams_app.Assignment')),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='submissions', to=settings.AUTH_USER_MODEL)),
            ],
        ),
    ]
