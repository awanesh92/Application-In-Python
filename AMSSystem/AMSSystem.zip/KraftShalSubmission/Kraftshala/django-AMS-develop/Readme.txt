1. Setup virtual environment 
2. Download the requirements using commond
 pip3 install -r requirements.txt (after going into the location in the folder)
3.Postgre is the required DB
There is a text for the structure of the tables in case needed.
4. Run the Django server
 python3 manage.py rumserver
5. Navigate to localhost:8000 in web browser for the application
